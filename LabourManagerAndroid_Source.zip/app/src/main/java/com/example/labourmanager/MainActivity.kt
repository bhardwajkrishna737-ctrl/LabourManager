package com.example.labourmanager

import android.app.DatePickerDialog
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = Database(this)
        setContent { MaterialTheme { LabourApp(db) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LabourApp(db: Database) {
    val context = LocalContext.current
    var workers by remember { mutableStateOf(db.workers()) }
    var selectedDate by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Calendar.getInstance().time)) }
    var month by remember { mutableStateOf(selectedDate.substring(0,7)) }
    var name by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("") }
    var paymentInputs by remember { mutableStateOf(mapOf<Long,String>()) }
    var notes by remember { mutableStateOf(mapOf<Long,String>()) }
    var refresh by remember { mutableIntStateOf(0) }

    fun reload() { workers = db.workers(); refresh++ }
    val prettyDate = selectedDate
    Scaffold(
        topBar = {
            TopAppBar(title = {
                Column {
                    Text("Labour Manager", fontWeight = FontWeight.Bold)
                    Text("Attendance & Payment Book", style = MaterialTheme.typography.labelSmall)
                }
            })
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Daily Attendance", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Selected date: $prettyDate")
                        Button(onClick = {
                            val cal = Calendar.getInstance()
                            try {
                                val parts = selectedDate.split("-")
                                cal.set(parts[0].toInt(), parts[1].toInt()-1, parts[2].toInt())
                            } catch (_: Exception) {}
                            DatePickerDialog(context, { _, y, m, d ->
                                selectedDate = String.format(Locale.US, "%04d-%02d-%02d", y, m+1, d)
                                month = selectedDate.substring(0,7)
                                refresh++
                            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
                        }) { Text("Choose Date") }
                    }
                }
            }
            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Add Labour", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        OutlinedTextField(name, { name=it }, label={Text("Labour name")}, modifier=Modifier.fillMaxWidth(), singleLine=true)
                        OutlinedTextField(rate, { rate=it }, label={Text("Daily wage (₹)")}, modifier=Modifier.fillMaxWidth(), singleLine=true,
                            keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
                        Button(onClick = {
                            val r = rate.toDoubleOrNull()
                            if(name.isNotBlank() && r != null && r > 0) {
                                db.addWorker(name.trim(), r); name=""; rate=""; reload()
                            }
                        }, enabled=name.isNotBlank() && (rate.toDoubleOrNull() ?: 0.0)>0) { Text("＋ Add Labour") }
                    }
                }
            }
            item { Text("Labour List", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            if (workers.isEmpty()) item { Text("No labour added yet. Add a labour above.") }
            items(workers, key={it.id}) { worker ->
                val currentStatus = remember(worker.id, selectedDate, refresh) { db.attendance(worker.id, selectedDate) }
                val totals = remember(worker.id, month, refresh) { db.totals(worker.id, month, worker.rate) }
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(worker.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text("₹${worker.rate.toInt()}/day")
                            }
                            TextButton(onClick={ db.deleteWorker(worker.id); reload() }) { Text("Delete") }
                        }
                        Text("Attendance for $selectedDate")
                        var expanded by remember(worker.id, selectedDate) { mutableStateOf(false) }
                        Box {
                            OutlinedButton(onClick={expanded=true}) { Text(currentStatus) }
                            DropdownMenu(expanded=expanded, onDismissRequest={expanded=false}) {
                                listOf("Present","Half Day","Absent").forEach { status ->
                                    DropdownMenuItem(text={Text(status)}, onClick={
                                        db.setAttendance(worker.id, selectedDate, status)
                                        expanded=false; refresh++
                                    })
                                }
                            }
                        }
                        Divider()
                        Text("Monthly summary: $month", fontWeight=FontWeight.SemiBold)
                        Text("Present: ${totals.present}   Half: ${totals.half}   Absent: ${totals.absent}")
                        Text("Earned: ₹${"%.2f".format(totals.salary)}   Paid: ₹${"%.2f".format(totals.paid)}")
                        Text("Remaining: ₹${"%.2f".format(totals.salary-totals.paid)}",
                            color=if(totals.salary-totals.paid >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                            fontWeight=FontWeight.Bold)
                        OutlinedTextField(
                            value=paymentInputs[worker.id] ?: "",
                            onValueChange={ paymentInputs=paymentInputs + (worker.id to it) },
                            label={Text("Payment given (₹)")}, modifier=Modifier.fillMaxWidth(), singleLine=true,
                            keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal)
                        )
                        OutlinedTextField(
                            value=notes[worker.id] ?: "",
                            onValueChange={ notes=notes + (worker.id to it) },
                            label={Text("Payment note (optional)")}, modifier=Modifier.fillMaxWidth(), singleLine=true
                        )
                        Button(onClick={
                            val amount=(paymentInputs[worker.id] ?: "").toDoubleOrNull()
                            if(amount != null && amount > 0) {
                                db.addPayment(worker.id, selectedDate, amount, notes[worker.id] ?: "")
                                paymentInputs=paymentInputs - worker.id
                                notes=notes - worker.id
                                refresh++
                            }
                        }, enabled=(paymentInputs[worker.id] ?: "").toDoubleOrNull()?.let{it>0} == true) {
                            Text("Save Payment")
                        }
                    }
                }
            }
            item {
                Card(shape=RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(6.dp)) {
                        Text("Monthly report", style=MaterialTheme.typography.titleLarge, fontWeight=FontWeight.Bold)
                        Text("Month: $month")
                        Text("Labour count: ${workers.size}")
                        val all = workers.map { db.totals(it.id, month, it.rate) }
                        Text("Total earned: ₹${"%.2f".format(all.sumOf{it.salary})}")
                        Text("Total paid: ₹${"%.2f".format(all.sumOf{it.paid})}")
                        Text("Total remaining: ₹${"%.2f".format(all.sumOf{it.salary-it.paid})}", fontWeight=FontWeight.Bold)
                    }
                }
            }
            item { Text("Data is saved locally on this phone. Back up the app data before changing or resetting your phone.", style=MaterialTheme.typography.bodySmall) }
        }
    }
}
