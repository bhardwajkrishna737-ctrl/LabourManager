package com.example.labourmanager

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Worker(val id: Long, val name: String, val rate: Double)
data class DayRecord(val status: String, val amount: Double)
data class Totals(val present: Int, val half: Int, val absent: Int, val salary: Double, val paid: Double)

class Database(context: Context) : SQLiteOpenHelper(context, "labour_manager.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE workers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, rate REAL NOT NULL)")
        db.execSQL("CREATE TABLE attendance(id INTEGER PRIMARY KEY AUTOINCREMENT, worker_id INTEGER NOT NULL, day TEXT NOT NULL, status TEXT NOT NULL, UNIQUE(worker_id, day))")
        db.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT, worker_id INTEGER NOT NULL, day TEXT NOT NULL, amount REAL NOT NULL, note TEXT)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun addWorker(name: String, rate: Double) {
        writableDatabase.insert("workers", null, ContentValues().apply {
            put("name", name); put("rate", rate)
        })
    }
    fun workers(): List<Worker> {
        val result = mutableListOf<Worker>()
        readableDatabase.rawQuery("SELECT id,name,rate FROM workers ORDER BY name", null).use { c ->
            while (c.moveToNext()) result.add(Worker(c.getLong(0), c.getString(1), c.getDouble(2)))
        }
        return result
    }
    fun deleteWorker(id: Long) {
        writableDatabase.delete("attendance", "worker_id=?", arrayOf(id.toString()))
        writableDatabase.delete("payments", "worker_id=?", arrayOf(id.toString()))
        writableDatabase.delete("workers", "id=?", arrayOf(id.toString()))
    }
    fun setAttendance(workerId: Long, day: String, status: String) {
        val values = ContentValues().apply {
            put("worker_id", workerId); put("day", day); put("status", status)
        }
        writableDatabase.insertWithOnConflict("attendance", null, values, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun attendance(workerId: Long, day: String): String {
        readableDatabase.rawQuery("SELECT status FROM attendance WHERE worker_id=? AND day=?", arrayOf(workerId.toString(), day)).use {
            return if (it.moveToFirst()) it.getString(0) else "Not marked"
        }
    }
    fun addPayment(workerId: Long, day: String, amount: Double, note: String) {
        writableDatabase.insert("payments", null, ContentValues().apply {
            put("worker_id", workerId); put("day", day); put("amount", amount); put("note", note)
        })
    }
    fun totals(workerId: Long, month: String, rate: Double): Totals {
        var p=0; var h=0; var a=0
        readableDatabase.rawQuery("SELECT status,COUNT(*) FROM attendance WHERE worker_id=? AND substr(day,1,7)=? GROUP BY status",
            arrayOf(workerId.toString(), month)).use { c ->
            while (c.moveToNext()) when(c.getString(0)) {
                "Present" -> p=c.getInt(1)
                "Half Day" -> h=c.getInt(1)
                "Absent" -> a=c.getInt(1)
            }
        }
        var paid=0.0
        readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM payments WHERE worker_id=? AND substr(day,1,7)=?",
            arrayOf(workerId.toString(), month)).use { if(it.moveToFirst()) paid=it.getDouble(0) }
        return Totals(p,h,a,rate*(p+h/2.0),paid)
    }
}
