# Labour Manager Android App

A starter Android Studio project for labour attendance and wage tracking.

## Included
- Add labour with individual daily wage
- Choose an attendance date
- Mark Present / Half Day / Absent
- Record payments by date, with optional notes
- Monthly earned, paid, and remaining totals
- Local SQLite storage on the device

## Build APK
1. Install Android Studio (current stable version) on a computer.
2. Open this `LabourManager` folder in Android Studio.
3. Allow Gradle sync and install any requested Android SDK components (compile SDK 35).
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio creates the APK under `app/build/outputs/apk/debug/`.

## Important
- This is source code, not a prebuilt APK. An Android SDK/Gradle build environment is required to compile the APK.
- Data is stored locally in the app's SQLite database. It is not automatically synced or backed up to the cloud.
- Monthly salary is calculated from marked attendance: Present = 1 day, Half Day = 0.5 day, Absent = 0.
- The app currently uses the selected date's month for the monthly summary.
